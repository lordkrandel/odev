#!/usr/bin/bash

git branch -vv | grep "*"
